// src/components/Header.tsx
"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";

export default function Header() {
  
  const pathName = usePathname();

  function getLogo() {
    if (pathName.startsWith("/zibert")) return "/slike/logo-zibert.png";
    if (pathName.startsWith("/drive-in")) return "/slike/logo-drive-in.png";
    if (pathName.startsWith("/rooms")) return "/slike/logo-rooms.png";
    if (pathName.startsWith("/dogodki")) return "/slike/logo-dogodki.png";
    return "/slike/logo-taprav.png";
  }


  return (
    <header className="bg-white relative">
      <div className="px-4 py-2 flex justify-center">
        <Link href="/">
          <Image
            src={getLogo()}
            alt="Logo"
            width={150}
            height={50}
            className="h-auto w-auto"
            priority
          />
        </Link>
      </div>

    </header>
  );
}
